#!/bin/bash

java -jar whitematter.jar
